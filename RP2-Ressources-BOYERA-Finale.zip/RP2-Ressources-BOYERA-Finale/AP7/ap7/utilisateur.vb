﻿Imports MySql.Data.MySqlClient
Public Class frm_utilisateur
    Private Sub RemplirGrilleCategorie()
        Dim dtUtilisateur As New DataTable
        Dim sdaUtilisateur As New MySqlDataAdapter
        Dim query As String = "SELECT * FROM utilisateur"

        If rbn_visiteur.Checked Then
            query = "SELECT u.id, nom, prenom, login, mdp, adresse, cp, ville, dateEmbauche " &
                "FROM utilisateur u " &
                "INNER JOIN visiteur v ON u.id = v.id"
        ElseIf rbn_comptable.Checked Then
            query = "SELECT u.id, nom, prenom, login, mdp, adresse, cp, ville, dateEmbauche " &
                "FROM utilisateur u " &
                "INNER JOIN comptable c ON u.id = c.id"
        End If

        sdaUtilisateur.SelectCommand = New MySqlCommand(query, cnxGestionUtilisateur)
        sdaUtilisateur.Fill(dtUtilisateur)
        dgv_Utilisateur.DataSource = dtUtilisateur
        dgv_Utilisateur.SelectionMode = DataGridViewSelectionMode.FullRowSelect
    End Sub

    Private Sub btn_modifierMdp_Click(sender As Object, e As EventArgs) Handles btn_modifier.Click
        If dgv_Utilisateur.SelectedRows.Count > 0 Then
            Dim selectedRow As DataGridViewRow = dgv_Utilisateur.SelectedRows(0)

            Dim userId As String = selectedRow.Cells("id").Value.ToString()
            Dim nouveauMdp As String = "Start123!"

            If Not String.IsNullOrEmpty(nouveauMdp) Then
                ModifierMdpUtilisateur(userId, nouveauMdp)
            Else
                MessageBox.Show("Le mot de passe ne peut pas être vide.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        Else
            MessageBox.Show("Veuillez sélectionner un utilisateur.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Warning)
        End If
    End Sub
    Private Sub btn_enregistrerModif_Click(sender As Object, e As EventArgs) Handles btn_enregistrerModif.Click
        ' Vérifie si y'a une ligne sélectionnée dans le tableau et la récup
        If dgv_Utilisateur.SelectedRows.Count = 0 Then
            MessageBox.Show("Veuillez sélectionner un utilisateur.", "Attention", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Exit Sub
        End If
        Dim ligne As DataGridViewRow = dgv_Utilisateur.SelectedRows(0)

        ' Requête SQL pour modif l'user
        Dim requete As String = "UPDATE utilisateur SET nom = @nom, prenom = @prenom, login = @login, mdp = @mdp, adresse = @adresse, cp = @cp, ville = @ville, dateEmbauche = @dateEmbauche WHERE id = @id"

        Try
            Dim cmd As New MySqlCommand(requete, cnxGestionUtilisateur)

            ' Ajout des paramètres
            cmd.Parameters.AddWithValue("@id", ligne.Cells("id").Value)
            cmd.Parameters.AddWithValue("@nom", ligne.Cells("nom").Value)
            cmd.Parameters.AddWithValue("@prenom", ligne.Cells("prenom").Value)
            cmd.Parameters.AddWithValue("@login", ligne.Cells("login").Value)
            cmd.Parameters.AddWithValue("@mdp", ligne.Cells("mdp").Value)
            cmd.Parameters.AddWithValue("@adresse", ligne.Cells("adresse").Value)
            cmd.Parameters.AddWithValue("@cp", ligne.Cells("cp").Value)
            cmd.Parameters.AddWithValue("@ville", ligne.Cells("ville").Value)
            cmd.Parameters.AddWithValue("@dateEmbauche", ligne.Cells("dateEmbauche").Value)

            cmd.ExecuteNonQuery()

            ' Message de confirmation
            MessageBox.Show("Utilisateur modifié avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information)

            RemplirGrilleCategorie()
        Catch ex As Exception
            MessageBox.Show("Erreur : " & ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub ModifierMdpUtilisateur(userId As String, nouveauMdp As String)
        Try
            Dim query As String = "UPDATE utilisateur SET mdp = SHA1(@nouveauMdp) WHERE id = @userId"

            Using command As New MySqlCommand(query, cnxGestionUtilisateur)
                command.Parameters.AddWithValue("@nouveauMdp", nouveauMdp)
                command.Parameters.AddWithValue("@userId", userId)


                command.ExecuteNonQuery()
                MessageBox.Show("Mot de passe mis à jour avec succès.", "Succès", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End Using
        Catch ex As MySqlException
            MessageBox.Show("Erreur lors de la mise à jour du mot de passe : " & ex.Message, "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If cnxGestionUtilisateur.State = ConnectionState.Open Then
                cnxGestionUtilisateur.Close()
            End If
        End Try
    End Sub

    Private Sub frm_utilisateur_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        initialiserConnexionBD()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btn_creationUtilisateur.Click
        frm_creationUtil.Show()
    End Sub
    Private Sub rbt_Visiteur_CheckedChanged(sender As Object, e As EventArgs) Handles rbn_visiteur.CheckedChanged
        RemplirGrilleCategorie()
    End Sub

    Private Sub rbt_Comptable_CheckedChanged(sender As Object, e As EventArgs) Handles rbn_comptable.CheckedChanged
        RemplirGrilleCategorie()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub
End Class