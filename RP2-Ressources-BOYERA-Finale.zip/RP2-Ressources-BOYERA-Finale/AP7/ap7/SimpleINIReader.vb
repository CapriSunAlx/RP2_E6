﻿Imports System.IO

Module SimpleINIReader

    ' Fonction pour lire la valeur d'une clé spécifique dans une section spécifique
    Public Function GetINIValue(filePath As String, section As String, key As String) As String
        Dim isInSection As Boolean = False
        For Each line As String In File.ReadLines(filePath)
            If line.StartsWith("[") AndAlso line.EndsWith("]") Then
                ' Détermine si la ligne actuelle marque le début de la section recherchée
                isInSection = line.Equals($"[{section}]", StringComparison.OrdinalIgnoreCase)
            ElseIf isInSection AndAlso line.StartsWith(key & "=", StringComparison.OrdinalIgnoreCase) Then
                ' Retourne la valeur si la ligne commence par la clé recherchée
                Return line.Substring(line.IndexOf("=") + 1).Trim()
            End If
        Next
        Return String.Empty
    End Function

End Module
