﻿Imports MySql.Data.MySqlClient

Module md_ConnexionBD
    Public cnxGestionUtilisateur As MySqlConnection

    Public Sub initialiserConnexionBD()
        ' Chemin vers le fichier INI
        Dim pathToIni As String = "D:\BTS-SIO\BTS SIO2(2024-2025)\Informatique\AP\AP7\gsb.ini"

        ' Lecture des informations de connexion
        Dim server As String = SimpleINIReader.GetINIValue(pathToIni, "Database", "host")
        Dim user As String = SimpleINIReader.GetINIValue(pathToIni, "Database", "user")
        Dim database As String = SimpleINIReader.GetINIValue(pathToIni, "Database", "database")
        Dim port As String = SimpleINIReader.GetINIValue(pathToIni, "Database", "port")
        Dim password As String = SimpleINIReader.GetINIValue(pathToIni, "Database", "password")

        ' Construction de la chaîne de connexion
        Dim itemsConnexion As String = $"server={server};user={user};database={database};port={port};password={password}"

        cnxGestionUtilisateur = New MySqlConnection(itemsConnexion)

        Try
            cnxGestionUtilisateur.Open()
        Catch ex As Exception
            MsgBox("Erreur: Accès à la BD impossible !" + Chr(13) + ex.Message, vbCritical)
        End Try
    End Sub
End Module
