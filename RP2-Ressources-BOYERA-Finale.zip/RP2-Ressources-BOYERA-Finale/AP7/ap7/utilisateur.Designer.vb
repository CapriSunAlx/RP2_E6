﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frm_utilisateur
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl_utilisateur = New System.Windows.Forms.Label()
        Me.dgv_Utilisateur = New System.Windows.Forms.DataGridView()
        Me.btn_creationUtilisateur = New System.Windows.Forms.Button()
        Me.btn_modifier = New System.Windows.Forms.Button()
        Me.rbn_visiteur = New System.Windows.Forms.RadioButton()
        Me.rbn_comptable = New System.Windows.Forms.RadioButton()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.btn_enregistrerModif = New System.Windows.Forms.Button()
        CType(Me.dgv_Utilisateur, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbl_utilisateur
        '
        Me.lbl_utilisateur.AutoSize = True
        Me.lbl_utilisateur.BackColor = System.Drawing.Color.Transparent
        Me.lbl_utilisateur.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_utilisateur.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.lbl_utilisateur.Location = New System.Drawing.Point(-5, 6)
        Me.lbl_utilisateur.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_utilisateur.Name = "lbl_utilisateur"
        Me.lbl_utilisateur.Size = New System.Drawing.Size(372, 38)
        Me.lbl_utilisateur.TabIndex = 0
        Me.lbl_utilisateur.Text = "La liste des utilisateurs"
        '
        'dgv_Utilisateur
        '
        Me.dgv_Utilisateur.BackgroundColor = System.Drawing.Color.White
        Me.dgv_Utilisateur.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgv_Utilisateur.Location = New System.Drawing.Point(9, 162)
        Me.dgv_Utilisateur.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dgv_Utilisateur.Name = "dgv_Utilisateur"
        Me.dgv_Utilisateur.RowHeadersWidth = 51
        Me.dgv_Utilisateur.Size = New System.Drawing.Size(827, 417)
        Me.dgv_Utilisateur.TabIndex = 1
        '
        'btn_creationUtilisateur
        '
        Me.btn_creationUtilisateur.Location = New System.Drawing.Point(849, 209)
        Me.btn_creationUtilisateur.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn_creationUtilisateur.Name = "btn_creationUtilisateur"
        Me.btn_creationUtilisateur.Size = New System.Drawing.Size(193, 54)
        Me.btn_creationUtilisateur.TabIndex = 2
        Me.btn_creationUtilisateur.Text = "Ajouter un Utilisateur"
        Me.btn_creationUtilisateur.UseVisualStyleBackColor = True
        '
        'btn_modifier
        '
        Me.btn_modifier.Location = New System.Drawing.Point(849, 286)
        Me.btn_modifier.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn_modifier.Name = "btn_modifier"
        Me.btn_modifier.Size = New System.Drawing.Size(193, 57)
        Me.btn_modifier.TabIndex = 3
        Me.btn_modifier.Text = "Réinitialiser le mot de passe"
        Me.btn_modifier.UseVisualStyleBackColor = True
        '
        'rbn_visiteur
        '
        Me.rbn_visiteur.AutoSize = True
        Me.rbn_visiteur.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbn_visiteur.ForeColor = System.Drawing.Color.White
        Me.rbn_visiteur.Location = New System.Drawing.Point(108, 121)
        Me.rbn_visiteur.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbn_visiteur.Name = "rbn_visiteur"
        Me.rbn_visiteur.Size = New System.Drawing.Size(117, 20)
        Me.rbn_visiteur.TabIndex = 4
        Me.rbn_visiteur.TabStop = True
        Me.rbn_visiteur.Text = "Les Visiteurs"
        Me.rbn_visiteur.UseVisualStyleBackColor = True
        '
        'rbn_comptable
        '
        Me.rbn_comptable.AutoSize = True
        Me.rbn_comptable.Font = New System.Drawing.Font("Microsoft Sans Serif", 7.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rbn_comptable.ForeColor = System.Drawing.Color.White
        Me.rbn_comptable.Location = New System.Drawing.Point(345, 121)
        Me.rbn_comptable.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.rbn_comptable.Name = "rbn_comptable"
        Me.rbn_comptable.Size = New System.Drawing.Size(140, 20)
        Me.rbn_comptable.TabIndex = 5
        Me.rbn_comptable.TabStop = True
        Me.rbn_comptable.Text = "Les Comptables"
        Me.rbn_comptable.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(27, 78)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(299, 25)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Que souhaitez vous afficher ?"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(844, 162)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 25)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Autres options :"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.lbl_utilisateur)
        Me.Panel1.Location = New System.Drawing.Point(303, 12)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(471, 52)
        Me.Panel1.TabIndex = 8
        '
        'PictureBox1
        '
        Me.PictureBox1.ImageLocation = "D:\BTS-SIO\SIO2\AP\AP7\ap7\ap7\logo.jpg"
        Me.PictureBox1.Location = New System.Drawing.Point(403, 4)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(64, 46)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'btn_enregistrerModif
        '
        Me.btn_enregistrerModif.Location = New System.Drawing.Point(849, 363)
        Me.btn_enregistrerModif.Margin = New System.Windows.Forms.Padding(4)
        Me.btn_enregistrerModif.Name = "btn_enregistrerModif"
        Me.btn_enregistrerModif.Size = New System.Drawing.Size(193, 57)
        Me.btn_enregistrerModif.TabIndex = 9
        Me.btn_enregistrerModif.Text = "Enregistrer les modifications"
        Me.btn_enregistrerModif.UseVisualStyleBackColor = True
        '
        'frm_utilisateur
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1067, 636)
        Me.Controls.Add(Me.btn_enregistrerModif)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.rbn_comptable)
        Me.Controls.Add(Me.rbn_visiteur)
        Me.Controls.Add(Me.btn_modifier)
        Me.Controls.Add(Me.btn_creationUtilisateur)
        Me.Controls.Add(Me.dgv_Utilisateur)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frm_utilisateur"
        Me.Text = "utilisateur"
        CType(Me.dgv_Utilisateur, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl_utilisateur As Label
    Friend WithEvents dgv_Utilisateur As DataGridView
    Friend WithEvents btn_creationUtilisateur As Button
    Friend WithEvents btn_modifier As Button
    Friend WithEvents rbn_visiteur As RadioButton
    Friend WithEvents rbn_comptable As RadioButton
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btn_enregistrerModif As Button
End Class
