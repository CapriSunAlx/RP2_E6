﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frm_creationUtil
    Inherits System.Windows.Forms.Form

    'Form remplace la méthode Dispose pour nettoyer la liste des composants.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requise par le Concepteur Windows Form
    Private components As System.ComponentModel.IContainer

    'REMARQUE : la procédure suivante est requise par le Concepteur Windows Form
    'Elle peut être modifiée à l'aide du Concepteur Windows Form.  
    'Ne la modifiez pas à l'aide de l'éditeur de code.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lbl_nom = New System.Windows.Forms.Label()
        Me.lbl_prenom = New System.Windows.Forms.Label()
        Me.lbl_login = New System.Windows.Forms.Label()
        Me.lbl_mdp = New System.Windows.Forms.Label()
        Me.lbl_adresse = New System.Windows.Forms.Label()
        Me.lbl_cp = New System.Windows.Forms.Label()
        Me.lbl_ville = New System.Windows.Forms.Label()
        Me.txt_nom = New System.Windows.Forms.TextBox()
        Me.txt_cp = New System.Windows.Forms.TextBox()
        Me.txt_adresse = New System.Windows.Forms.TextBox()
        Me.txt_mdp = New System.Windows.Forms.TextBox()
        Me.txt_login = New System.Windows.Forms.TextBox()
        Me.txt_prenom = New System.Windows.Forms.TextBox()
        Me.txt_ville = New System.Windows.Forms.TextBox()
        Me.btn_creation = New System.Windows.Forms.Button()
        Me.cbo_fonction = New System.Windows.Forms.ComboBox()
        Me.txt_id = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dateEmbauche = New System.Windows.Forms.DateTimePicker()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lbl_utilisateur = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'lbl_nom
        '
        Me.lbl_nom.AutoSize = True
        Me.lbl_nom.Location = New System.Drawing.Point(108, 47)
        Me.lbl_nom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_nom.Name = "lbl_nom"
        Me.lbl_nom.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lbl_nom.Size = New System.Drawing.Size(42, 16)
        Me.lbl_nom.TabIndex = 1
        Me.lbl_nom.Text = "Nom :"
        '
        'lbl_prenom
        '
        Me.lbl_prenom.AutoSize = True
        Me.lbl_prenom.Location = New System.Drawing.Point(91, 81)
        Me.lbl_prenom.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_prenom.Name = "lbl_prenom"
        Me.lbl_prenom.Size = New System.Drawing.Size(60, 16)
        Me.lbl_prenom.TabIndex = 2
        Me.lbl_prenom.Text = "Prénom :"
        '
        'lbl_login
        '
        Me.lbl_login.AutoSize = True
        Me.lbl_login.Location = New System.Drawing.Point(104, 121)
        Me.lbl_login.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_login.Name = "lbl_login"
        Me.lbl_login.Size = New System.Drawing.Size(46, 16)
        Me.lbl_login.TabIndex = 3
        Me.lbl_login.Text = "Login :"
        '
        'lbl_mdp
        '
        Me.lbl_mdp.AutoSize = True
        Me.lbl_mdp.Location = New System.Drawing.Point(55, 164)
        Me.lbl_mdp.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_mdp.Name = "lbl_mdp"
        Me.lbl_mdp.Size = New System.Drawing.Size(95, 16)
        Me.lbl_mdp.TabIndex = 4
        Me.lbl_mdp.Text = "Mot de passe :"
        '
        'lbl_adresse
        '
        Me.lbl_adresse.AutoSize = True
        Me.lbl_adresse.Location = New System.Drawing.Point(85, 203)
        Me.lbl_adresse.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_adresse.Name = "lbl_adresse"
        Me.lbl_adresse.Size = New System.Drawing.Size(64, 16)
        Me.lbl_adresse.TabIndex = 5
        Me.lbl_adresse.Text = "Adresse :"
        '
        'lbl_cp
        '
        Me.lbl_cp.AutoSize = True
        Me.lbl_cp.Location = New System.Drawing.Point(64, 245)
        Me.lbl_cp.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_cp.Name = "lbl_cp"
        Me.lbl_cp.Size = New System.Drawing.Size(86, 16)
        Me.lbl_cp.TabIndex = 6
        Me.lbl_cp.Text = "Code postal :"
        '
        'lbl_ville
        '
        Me.lbl_ville.AutoSize = True
        Me.lbl_ville.Location = New System.Drawing.Point(109, 278)
        Me.lbl_ville.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_ville.Name = "lbl_ville"
        Me.lbl_ville.Size = New System.Drawing.Size(39, 16)
        Me.lbl_ville.TabIndex = 7
        Me.lbl_ville.Text = "Ville :"
        '
        'txt_nom
        '
        Me.txt_nom.Location = New System.Drawing.Point(159, 44)
        Me.txt_nom.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_nom.Name = "txt_nom"
        Me.txt_nom.Size = New System.Drawing.Size(231, 22)
        Me.txt_nom.TabIndex = 8
        '
        'txt_cp
        '
        Me.txt_cp.Location = New System.Drawing.Point(159, 242)
        Me.txt_cp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_cp.Name = "txt_cp"
        Me.txt_cp.Size = New System.Drawing.Size(231, 22)
        Me.txt_cp.TabIndex = 9
        '
        'txt_adresse
        '
        Me.txt_adresse.Location = New System.Drawing.Point(159, 203)
        Me.txt_adresse.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_adresse.Name = "txt_adresse"
        Me.txt_adresse.Size = New System.Drawing.Size(231, 22)
        Me.txt_adresse.TabIndex = 10
        '
        'txt_mdp
        '
        Me.txt_mdp.Location = New System.Drawing.Point(159, 161)
        Me.txt_mdp.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_mdp.Name = "txt_mdp"
        Me.txt_mdp.Size = New System.Drawing.Size(231, 22)
        Me.txt_mdp.TabIndex = 11
        '
        'txt_login
        '
        Me.txt_login.Location = New System.Drawing.Point(159, 121)
        Me.txt_login.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_login.Name = "txt_login"
        Me.txt_login.Size = New System.Drawing.Size(231, 22)
        Me.txt_login.TabIndex = 12
        '
        'txt_prenom
        '
        Me.txt_prenom.Location = New System.Drawing.Point(159, 81)
        Me.txt_prenom.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_prenom.Name = "txt_prenom"
        Me.txt_prenom.Size = New System.Drawing.Size(231, 22)
        Me.txt_prenom.TabIndex = 13
        '
        'txt_ville
        '
        Me.txt_ville.Location = New System.Drawing.Point(159, 278)
        Me.txt_ville.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_ville.Name = "txt_ville"
        Me.txt_ville.Size = New System.Drawing.Size(231, 22)
        Me.txt_ville.TabIndex = 14
        '
        'btn_creation
        '
        Me.btn_creation.Location = New System.Drawing.Point(155, 401)
        Me.btn_creation.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.btn_creation.Name = "btn_creation"
        Me.btn_creation.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.btn_creation.Size = New System.Drawing.Size(237, 39)
        Me.btn_creation.TabIndex = 15
        Me.btn_creation.Text = "Création de l'utilisateur"
        Me.btn_creation.UseVisualStyleBackColor = True
        '
        'cbo_fonction
        '
        Me.cbo_fonction.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cbo_fonction.FormattingEnabled = True
        Me.cbo_fonction.Location = New System.Drawing.Point(160, 354)
        Me.cbo_fonction.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.cbo_fonction.Name = "cbo_fonction"
        Me.cbo_fonction.Size = New System.Drawing.Size(231, 24)
        Me.cbo_fonction.TabIndex = 18
        '
        'txt_id
        '
        Me.txt_id.Location = New System.Drawing.Point(159, 12)
        Me.txt_id.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.txt_id.Name = "txt_id"
        Me.txt_id.Size = New System.Drawing.Size(231, 22)
        Me.txt_id.TabIndex = 20
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(125, 15)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(24, 16)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Id :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(25, 356)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(126, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Role de l'utilisateur :"
        '
        'dateEmbauche
        '
        Me.dateEmbauche.Location = New System.Drawing.Point(160, 316)
        Me.dateEmbauche.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.dateEmbauche.MinDate = New Date(2025, 3, 27, 0, 0, 0, 0)
        Me.dateEmbauche.Name = "dateEmbauche"
        Me.dateEmbauche.Size = New System.Drawing.Size(229, 22)
        Me.dateEmbauche.TabIndex = 22
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(29, 316)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 16)
        Me.Label3.TabIndex = 23
        Me.Label3.Text = "Date d'embauche :"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Controls.Add(Me.lbl_utilisateur)
        Me.Panel1.Location = New System.Drawing.Point(324, 25)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(471, 52)
        Me.Panel1.TabIndex = 26
        '
        'PictureBox1
        '
        Me.PictureBox1.ImageLocation = "D:\BTS-SIO\SIO2\AP\AP7\ap7\ap7\logo.jpg"
        Me.PictureBox1.Location = New System.Drawing.Point(416, 7)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(57, 42)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        '
        'lbl_utilisateur
        '
        Me.lbl_utilisateur.AutoSize = True
        Me.lbl_utilisateur.BackColor = System.Drawing.Color.Transparent
        Me.lbl_utilisateur.Font = New System.Drawing.Font("Microsoft Sans Serif", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lbl_utilisateur.ForeColor = System.Drawing.SystemColors.ActiveCaption
        Me.lbl_utilisateur.Location = New System.Drawing.Point(-5, 7)
        Me.lbl_utilisateur.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lbl_utilisateur.Name = "lbl_utilisateur"
        Me.lbl_utilisateur.Size = New System.Drawing.Size(382, 38)
        Me.lbl_utilisateur.TabIndex = 0
        Me.lbl_utilisateur.Text = "Création d'un utilisateur"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.White
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.dateEmbauche)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.txt_id)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.cbo_fonction)
        Me.Panel2.Controls.Add(Me.btn_creation)
        Me.Panel2.Controls.Add(Me.txt_ville)
        Me.Panel2.Controls.Add(Me.txt_prenom)
        Me.Panel2.Controls.Add(Me.txt_login)
        Me.Panel2.Controls.Add(Me.txt_mdp)
        Me.Panel2.Controls.Add(Me.txt_adresse)
        Me.Panel2.Controls.Add(Me.txt_cp)
        Me.Panel2.Controls.Add(Me.txt_nom)
        Me.Panel2.Controls.Add(Me.lbl_ville)
        Me.Panel2.Controls.Add(Me.lbl_cp)
        Me.Panel2.Controls.Add(Me.lbl_adresse)
        Me.Panel2.Controls.Add(Me.lbl_mdp)
        Me.Panel2.Controls.Add(Me.lbl_login)
        Me.Panel2.Controls.Add(Me.lbl_prenom)
        Me.Panel2.Controls.Add(Me.lbl_nom)
        Me.Panel2.Location = New System.Drawing.Point(324, 85)
        Me.Panel2.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(471, 450)
        Me.Panel2.TabIndex = 27
        '
        'frm_creationUtil
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(1067, 604)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Name = "frm_creationUtil"
        Me.Text = "creationUtil"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents lbl_nom As Label
    Friend WithEvents lbl_prenom As Label
    Friend WithEvents lbl_login As Label
    Friend WithEvents lbl_mdp As Label
    Friend WithEvents lbl_adresse As Label
    Friend WithEvents lbl_cp As Label
    Friend WithEvents lbl_ville As Label
    Friend WithEvents txt_nom As TextBox
    Friend WithEvents txt_cp As TextBox
    Friend WithEvents txt_adresse As TextBox
    Friend WithEvents txt_mdp As TextBox
    Friend WithEvents txt_login As TextBox
    Friend WithEvents txt_prenom As TextBox
    Friend WithEvents txt_ville As TextBox
    Friend WithEvents btn_creation As Button
    Friend WithEvents cbo_fonction As ComboBox
    Friend WithEvents txt_id As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents dateEmbauche As DateTimePicker
    Friend WithEvents Label3 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lbl_utilisateur As Label
    Friend WithEvents Panel2 As Panel
End Class
