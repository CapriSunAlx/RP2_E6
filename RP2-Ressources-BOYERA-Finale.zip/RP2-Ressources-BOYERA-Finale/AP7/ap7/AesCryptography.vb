﻿Imports System.Security.Cryptography
Imports System.IO
Imports System.Text

Module AesCryptography
    Private ReadOnly Key As Byte() = Encoding.UTF8.GetBytes("16CharSecretKey!")
    Private ReadOnly IV As Byte() = Encoding.UTF8.GetBytes("16CharInitVector")

    Public Function DecryptStringFromBytes_Aes(cipherText As String) As String
        Dim plaintext As String = Nothing

        Using aesAlg As Aes = Aes.Create()
            aesAlg.Key = Key
            aesAlg.IV = IV

            Dim decryptor As ICryptoTransform = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV)
            Dim cipherTextBytes As Byte() = Convert.FromBase64String(cipherText)
            Using msDecrypt As New MemoryStream(cipherTextBytes)
                Using csDecrypt As New CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read)
                    Using srDecrypt As New StreamReader(csDecrypt)
                        plaintext = srDecrypt.ReadToEnd()
                    End Using
                End Using
            End Using
        End Using

        Return plaintext
    End Function
End Module
