﻿Public Class frm_Connexion
    ' Chemin vers le fichier INI
    Private ReadOnly pathToIni As String = "D:\BTS-SIO\SIO2\AP\AP7\ap7\gsb.ini"

    Private Sub btn_connexion_Click(sender As Object, e As EventArgs) Handles btn_connexion.Click
        ' Lecture du mot de passe chiffré (code) depuis le fichier INI
        Dim encryptedCode As String = SimpleINIReader.GetINIValue(pathToIni, "AccesCode", "code")

        ' Déchiffrement du code
        Dim decryptedCode As String = AesCryptography.DecryptStringFromBytes_Aes(encryptedCode)

        ' Obtention du mot de passe entré par l'utilisateur
        Dim enteredPassword As String = txtBox_Mdp.Text

        ' Compare le mot de passe entré avec le mot de passe déchiffré
        If enteredPassword = decryptedCode Then

            frm_utilisateur.Show()
            Me.Hide()
        Else

            MessageBox.Show("Mot de passe incorrect.", "Erreur", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtBox_Mdp.Clear()
        End If
    End Sub

    Private Sub frm_Connexion_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub


End Class
