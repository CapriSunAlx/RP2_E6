﻿Imports MySql.Data.MySqlClient

Public Class frm_creationUtil

    Private Sub frm_creationUtil_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cbo_fonction.Items.Clear()
        cbo_fonction.Items.Add("Visiteur")
        cbo_fonction.Items.Add("Comptable")
    End Sub

    Private Sub ajoutUtilisateur()
        Try

            Dim command As New MySqlCommand("
                INSERT INTO utilisateur (id, nom, prenom, login, mdp, adresse, cp, ville, dateEmbauche)
                VALUES (@id, @Nom, @Prenom, @Login, SHA2(@Mdp, 256), @Adresse, @CodePostal, @Ville, @dateEmbauche)", cnxGestionUtilisateur)

            command.Parameters.AddWithValue("@id", txt_id.Text)
            command.Parameters.AddWithValue("@Nom", txt_nom.Text)
            command.Parameters.AddWithValue("@Prenom", txt_prenom.Text)
            command.Parameters.AddWithValue("@Login", txt_login.Text)
            command.Parameters.AddWithValue("@Mdp", txt_mdp.Text)
            command.Parameters.AddWithValue("@Adresse", txt_adresse.Text)
            command.Parameters.AddWithValue("@CodePostal", txt_cp.Text)
            command.Parameters.AddWithValue("@Ville", txt_ville.Text)
            command.Parameters.AddWithValue("@dateEmbauche", dateEmbauche.Value.ToString("yyyy-MM-dd"))
            command.ExecuteNonQuery()


            If cbo_fonction.Text = "Comptable" Then
                Dim cmdRole As New MySqlCommand("INSERT INTO comptable (id, nbFicheRefusee) VALUES (@id, 0)", cnxGestionUtilisateur)
                cmdRole.Parameters.AddWithValue("@id", txt_id.Text)
                cmdRole.ExecuteNonQuery()
            ElseIf cbo_fonction.Text = "Visiteur" Then
                Dim cmdRole As New MySqlCommand("INSERT INTO visiteur (id) VALUES (@id)", cnxGestionUtilisateur)
                cmdRole.Parameters.AddWithValue("@id", txt_id.Text)
                cmdRole.ExecuteNonQuery()
            Else
                MessageBox.Show("Veuillez sélectionner un rôle valide.")
                Exit Sub
            End If

            MessageBox.Show("Utilisateur ajouté avec succès.")
        Catch ex As MySqlException
            MessageBox.Show("Erreur lors de l'insertion des données : " & ex.Message)
        End Try
    End Sub

    Private Sub btn_creation_Click(sender As Object, e As EventArgs) Handles btn_creation.Click
        initialiserConnexionBD()
        ajoutUtilisateur()
        frm_utilisateur.Show()
    End Sub
End Class
